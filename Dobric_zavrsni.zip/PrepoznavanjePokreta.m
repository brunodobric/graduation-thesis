t = tcpip('127.0.0.1',30001);
fopen(t);
pause(0.2);
for x=1:50
    if exist(['pokret' num2str(x) '.txt'])==2
B=csvread(['pokret' num2str(x) '.txt']);
   data=0;
%%% trazi se manja vrijednost izme?u prve i zadnje x koordinate
if min(B(1,1),B(end,1))==B(1,1)
    Cx=1; %% ako je vrijednost prve x koordinate manja
else
    Cx=2; %% ako je vrijednost zadnje x koordinate manja
end
if min(B(1,2),B(end,2))==B(1,2)
    Cy=1; 
else
    Cy=2;
end
if min(B(1,3),B(end,3))==B(1,3)
    Cz=1;
else
    Cz=2;
end

%%% udaljenost prve i zadnje tocke
D=sqrt(power((B(1,1)-B(end,1)),2)+power((B(1,2)-B(end,2)),2)+power((B(1,3)-B(end,3)),2));
%%% razlika izmedu najvece i najmanje vrijednosti u smjeru svih osiju
M=max(B)-min(B);
MX=abs(M(1,1));
MY=abs(M(1,2));
MZ=abs(M(1,3));
G=B(1:end,1);
MU=MX-MY;
mean(G);
%%plot(G);

%%% razlika izmedu prve i zadnje tocke u smjeru svih osiju
R=B(1,1:end)-B(end,1:end);
RX=abs(R(1,1));
RY=abs(R(1,2));
RZ=abs(R(1,3));
%%% brzine i ubrzanja
V=abs(diff(B));
A=abs(diff(B,2));
VX=V(1:end,1);
VY=V(1:end,2);
VZ=V(1:end,3);
mean(A);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Je li ravni pokret?
PMy=0;
PMx=0;
VS=0;
VK=0;
PD=0;
PRx=0;
if MX>400 
    PMx=1;
elseif MX>350
    PMx=0.8;
end
if MY<200
    PMy=1;
elseif MY<260
    PMy=0.8;
elseif MY<300
    PMy=0.6;
end
if D>300
    PD=1;
end
if RX>390
    PRx=1;
elseif RX>200
    PRx=0.6;
end
VR=((2*PMx+4*PMy+2*PD+PRx)/9)*100;
if VR>=85
    if Cx==1
        fprintf('POKRET DESNO UZ SIGURNOST %2.f%% (SINUSOIDA %2.f%%, KRUZNI POKRET %2.f%%)\n',VR,VS,VK);
        data='(1,1)';
    else
        fprintf('POKRET LIJEVO UZ SIGURNOST %2.f%% (SINUSOIDA %2.f%%, KRUZNI POKRET %2.f%%)\n',VR,VS,VK);
        data='(2,1)';
    end
end

%Je li sinusoida?
PMy=0;
PMx=0;
PD=0;
PRx=0;
PMy=0;
if MX>200 
    PMx=1;
elseif MX>180
    PMx=0.8;
end
if MY>300
    PMy=1;
elseif MY>260
    PMy=0.8;
end
if D>300
    PD=1;
end
if RX>390
    PRx=1;
elseif RX>300
    PRx=0.6;
end
VS=((2*PMx+4*PMy+2*PD+2*PRx)/10)*100;
if VS>=85
    fprintf('POKRET SINUSOIDA UZ SIGURNOST %2.f%% (KRUZNI POKRET %2.f%%, RAVNI POKRET %2.f%%)\n',VS,VK,VR);
    data='(3,1)';
end

%Je li kruzni pokret?
PMy=0;
PMu=0;
PD=0;
PRx=0;
PMy=0;
if MU<100 
    PMu=1;
elseif MU<200
    PMu=0.8;
elseif MU<300
    PMu=0.6;
end
if MY>500
    PMy=1;
elseif MY>300
    PMy=0.8;
end
if D<400
    PD=1;
elseif D<500
    PD=0.8;
end
if RX<100
    PRx=1;
elseif RX<200
    PRx=0.9;
end
VK=((2*PMu+3*PMy+PD+2*PRx)/8)*100;
if VK>=85
    fprintf('KRUZNI POKRET UZ SIGURNOST %2.f%% (SINUSOIDA %2.f%%, RAVNI POKRET %2.f%%)\n',VK,VS,VR);
    data='(4,1)';
end

%%Je li vertikalni pokret?
PMY=0;
PMX=0;
PMZ=0;
if MY>300
    PMY=1;
elseif MY>250
    PMY=0.8;
end
if MX<100
    PMX=1;
elseif MX<160
    PMX=0.8;
end
if MZ<150
    PMZ=1;
elseif PMZ<200
    PMZ=0.8;
end
VV=((2*PMY+PMX+PMZ)/4)*100;
if VV>=85
    if Cy==1
        fprintf('POKRET GORE UZ SIGURNOST %2.f%% (SINUSOIDA %2.f%%, KRUZNI POKRET %2.f%%)\n',VV,VS,VK);
        data='(5,1)';
    else
        fprintf('POKRET DOLJE UZ SIGURNOST %2.f%% (SINUSOIDA %2.f%%, KRUZNI POKRET %2.f%%)\n',VV,VS,VK);
        data='(6,1)';
    end
end  

%%Je li pokret naprijed, nazad?
PMY=0;
PMX=0;
PMZ=0;
if MY<150
    PMY=1;
elseif MY<200
    PMY=0.8;
end
if MX<100
    PMX=1;
elseif MX<150
    PMX=0.8;
end
if MZ>300
    PMZ=1;
end
VN=((2*PMY+PMX+PMZ)/4)*100;
if VN>=85
    if Cz==1
        fprintf('POKRET NAZAD UZ SIGURNOST %2.f%% (SINUSOIDA %2.f%%, KRUZNI POKRET %2.f%%)\n',VN,VS,VK);
        data='(7,1)';
    else
        fprintf('POKRET NAPRIJED UZ SIGURNOST %2.f%% (SINUSOIDA %2.f%%, KRUZNI POKRET %2.f%%)\n',VN,VS,VK);
        data='(8,1)';
    end
    
end  
fwrite(t, data);
    pause(1);
    delete(['pokret' num2str(x) '.txt']);
    else
        fprintf('KRAJ');
        return 
    end
    end
