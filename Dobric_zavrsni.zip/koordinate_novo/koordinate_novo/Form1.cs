﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Kinect;
using System.IO;
using System.Diagnostics;

namespace koordinate_novo
{

    public partial class Form1 : Form
    {
        
        KinectSensor kinectSensor = null;
        BodyFrameReader bodyFrameReader = null;
        Body[] bodies = null;


        int br = 1;
        int zat = 1;    
        int brp = 0;

        public Form1()
        {
            InitializeComponent();
            initialiseKinect();
            Process.Start(@"C:\\Users\brunodobric\\Desktop\\ServerCSharp\\ServerCSharp\\bin\\Release\\ServerCSharp.exe");
            System.Threading.Thread.Sleep(1000);
            
        }

        public void initialiseKinect()
        {
            kinectSensor = KinectSensor.GetDefault();
            if (kinectSensor != null)
            {
                //turn on kinect
                kinectSensor.Open();
            }

            bodyFrameReader = kinectSensor.BodyFrameSource.OpenReader();

            if (bodyFrameReader != null)
            {
                bodyFrameReader.FrameArrived += Reader_FrameArrived;
            }
        }
        private void Reader_FrameArrived(object sender, BodyFrameArrivedEventArgs e)
        {
            bool dataRecieved = false;

            using (BodyFrame bodyFrame = e.FrameReference.AcquireFrame())
            {
                if (bodyFrame != null)
                {
                    if (this.bodies == null)
                    {
                        this.bodies = new Body[bodyFrame.BodyCount];
                    }
                    bodyFrame.GetAndRefreshBodyData(this.bodies);
                    dataRecieved = true;
                }
            }

            

            if (dataRecieved)
            {
                foreach (Body body in bodies)
                {
                    if (body.IsTracked)
                    {

                        // Find the hand states
                        string rightHandState = "-";
                        string leftHandState = "-";

                        switch (body.HandRightState)
                        {
                            case HandState.Open:
                                rightHandState = "Otvorena";
                                break;
                            case HandState.Closed:
                                rightHandState = "Zatvorena";
                                break;
                            case HandState.Lasso:
                                rightHandState = "Lasso";
                                break;
                            case HandState.Unknown:
                                rightHandState = "Nepoznata...";
                                break;
                            case HandState.NotTracked:
                                rightHandState = "Izvan dometa";
                                break;
                            default:
                                break;
                        }




                        switch (body.HandLeftState)
                        {
                            case HandState.Open:
                                leftHandState = "Snimanje";
                                break;
                            case HandState.Closed:
                                leftHandState = "Čekanje";
                                break;
                            case HandState.Lasso:
                                leftHandState = "Obrada";
                                break;
                            case HandState.Unknown:
                                leftHandState = "Nepoznata...";
                                break;
                            case HandState.NotTracked:
                                leftHandState = "Izvan dometa";
                                break;
                            default:
                                break;
                        }

                        textBox1.Text = rightHandState;
                        textBox2.Text = leftHandState;


                        IReadOnlyDictionary<JointType, Joint> joints = body.Joints;
                        Dictionary<JointType, Point> jointPoints = new Dictionary<JointType, Point>();


                        Snimanje:
                        if (textBox2.Text == "Snimanje")
                        {


                            Joint lruka = joints[JointType.HandLeft];

                            float lrx = lruka.Position.X * 1000;
                            float lry = lruka.Position.Y * 1000;
                            float lrz = lruka.Position.Z * 1000;

                            Joint druka = joints[JointType.HandRight];

                            float drx = druka.Position.X * 1000;
                            float dry = druka.Position.Y * 1000;
                            float drz = druka.Position.Z * 1000;

                            textBox4.Text = drx.ToString("#.##");
                            textBox5.Text = dry.ToString("#.##");
                            textBox6.Text = drz.ToString("#.##");

                            //File.AppendAllText(@"pokret.txt", drx + ", " + dry + ", " + drz + Environment.NewLine);
                            using (StreamWriter w = File.AppendText("pokret" + br + ".txt"))
                            {
                                w.WriteLine(drx + ", " + dry + ", " + drz + Environment.NewLine);
                            }
                            if (zat == br)
                                zat = zat + 1;
                        }

                        else if (textBox2.Text == "Čekanje")
                        {

                            if (br < zat)
                            {
                                br = br + 1;
                                goto Snimanje;
                            }

                        }
                    

                    else if (textBox2.Text == "Obrada" && brp==0)
                    { 
                        Process.Start(@"PrepoznavanjePokreta.exe");
                            brp = brp + 1;
                            System.Threading.Thread.Sleep(5000);
                        }  


                            // Find the joints
                            Joint handRight = body.Joints[JointType.HandRight];
                        Joint thumbRight = body.Joints[JointType.ThumbRight];

                        Joint handLeft = body.Joints[JointType.HandLeft];
                        Joint thumbLeft = body.Joints[JointType.ThumbLeft];

                    }
                }
            }
        }

        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
             
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void btnServer_Click(object sender, EventArgs e)
        {          
            Process.Start(@"PrepoznavanjePokreta.exe");                 
        }        
    }   
}


 



