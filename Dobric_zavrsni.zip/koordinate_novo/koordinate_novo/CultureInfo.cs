﻿namespace koordinate_novo
{
    internal class CultureInfo
    {
    }
}