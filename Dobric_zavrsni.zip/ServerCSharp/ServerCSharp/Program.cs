﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<int, TcpClient> list_clients = new Dictionary<int, TcpClient>();

            int count = 1;


            TcpListener ServerSocket = new TcpListener(IPAddress.Any, 30001);
            ServerSocket.Start();

            while (true)
            {
                TcpClient client = ServerSocket.AcceptTcpClient();
                list_clients.Add(count, client);
                Console.WriteLine("Someone connected!!");
                count++;
                Box box = new Box(client, list_clients);

                Thread t = new Thread(handle_clients);
                t.Start(box);

            }

        }

        public static void handle_clients(object o)
        {
            Box box = (Box)o;
            Dictionary<int, TcpClient> list_connections = box.list;

            while (true)
            {
                const string provjera = "kreni";
                NetworkStream stream = box.c.GetStream();
                byte[] buffer = new byte[1024];
                int byte_count = stream.Read(buffer, 0, buffer.Length);
                byte[] formated = new Byte[byte_count];
                Array.Copy(buffer, formated, byte_count); //handle  the null characteres in the byte array
                string data = Encoding.ASCII.GetString(formated);
                broadcast(list_connections, data);
                Console.WriteLine("Received message request: " + data);


                string salji = string.Empty;

                salji = data;


                if (salji.Length > 0)
                {
                    Console.WriteLine("Sending message answer: " + salji);
                    // Convert the point into a byte array
                    byte[] arrayBytesAnswer = ASCIIEncoding.ASCII.GetBytes(salji);
                    // Send the byte array to the client
                    stream.Write(arrayBytesAnswer, 0, arrayBytesAnswer.Length);
                }


            }
        }



        public static void broadcast(Dictionary<int, TcpClient> conexoes, string data)
        {
            foreach (TcpClient c in conexoes.Values)
            {
                NetworkStream stream = c.GetStream();

                byte[] buffer = Encoding.ASCII.GetBytes(data);
                stream.Write(buffer, 0, buffer.Length);

            }
        }

    }
    class Box
    {
        public TcpClient c;
        public Dictionary<int, TcpClient> list;

        public Box(TcpClient c, Dictionary<int, TcpClient> list)
        {
            this.c = c;
            this.list = list;
        }

    }
}